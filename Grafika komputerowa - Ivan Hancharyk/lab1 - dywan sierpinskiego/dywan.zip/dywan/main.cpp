#include <iostream>
#include <GL/gl.h>
#include <GL/glut.h>
#include <limits>
#include <regex>

using namespace std;

double def_level;
int stopien;
double x = 0, y = 0, width;
bool kolorowy;
int wybor;
GLsizei windowWidth = 300, windowHeight = 300;
int current_step = 0;

// Rozszerzona paleta kolorów (15 kolorów)
float paleta_kolorow[15][3] = {
        {1.0f, 0.0f, 0.0f},  // Czerwony
        {0.0f, 1.0f, 0.0f},  // Zielony
        {0.0f, 0.0f, 1.0f},  // Niebieski
        {1.0f, 1.0f, 0.0f},  // Żółty
        {1.0f, 0.5f, 0.0f},  // Pomarańczowy
        {0.5f, 0.0f, 0.5f},  // Fioletowy
        {0.0f, 1.0f, 1.0f},  // Cyjan
        {1.0f, 0.0f, 1.0f},  // Magenta
        {0.5f, 1.0f, 0.0f},  // Limonkowy
        {0.0f, 0.5f, 1.0f},  // Jasnoniebieski
        {0.5f, 0.5f, 0.5f},  // Szary
        {0.75f, 0.25f, 0.25f}, // Ciemnoczerwony
        {0.25f, 0.75f, 0.25f}, // Ciemnozielony
        {0.25f, 0.25f, 0.75f}, // Ciemnoniebieski
        {1.0f, 0.8f, 0.6f}    // Beżowy
};

// Paleta kolorów dla trybu czarno-białego
float paleta_czarno_biala[2][3] = {
        {0.0f, 0.0f, 0.0f},  // Czarny
        {1.0f, 1.0f, 1.0f}   // Biały
};

void clearInput() {
    cin.clear();  // Resetowanie flagi błędu strumienia
    cin.ignore(numeric_limits<streamsize>::max(), '\n');  // Odrzucenie nieprawidłowych danych
}

bool isValidFloat(const string& input) {
    // Używamy regex, aby sprawdzić, czy dane wejściowe są prawidłową liczbą zmiennoprzecinkową
    regex floatRegex("^[0-9]*\\.?[0-9]+$");
    return regex_match(input, floatRegex);
}

bool isValidInt(const string& input) {
    // Używamy regex, aby sprawdzić, czy dane wejściowe są prawidłową liczbą całkowitą
    regex intRegex("^[0-9]+$");
    return regex_match(input, intRegex);
}

void init()
{
    string input;

    // Wprowadzanie liczby powtórzeń algorytmu
    while (true) {
        cout << "Podaj liczbe powtorzen algorytmu (1-5): ";
        getline(cin, input);  // Wczytujemy pełną linię tekstu
        if (isValidInt(input)) {  // Sprawdzamy, czy to poprawna liczba całkowita
            stringstream ss(input);
            if (ss >> stopien && stopien >= 1 && stopien <= 5) {
                break;
            }
        }
        cout << "Blad: prosze podac liczbe calkowita z zakresu 1-5." << endl;
        clearInput();
    }

    // Wprowadzanie stopnia deformacji
    while (true) {
        cout << "Podaj stopien deformacji (0-1): ";
        getline(cin, input);  // Wczytujemy pełną linię tekstu
        if (isValidFloat(input)) {  // Sprawdzamy, czy to poprawna liczba zmiennoprzecinkowa
            stringstream ss(input);
            if (ss >> def_level && def_level >= 0.0 && def_level <= 1.0) {
                break;
            }
        }
        cout << "Blad: prosze podac liczbe z zakresu 0 do 1." << endl;
        clearInput();
    }

    // Wybór trybu kolorowego lub czarno-białego
    while (true) {
        cout << "Wybierz tryb: 1 - Kolorowy, 2 - Czarno-bialy: ";
        getline(cin, input);  // Wczytujemy pełną linię tekstu
        if (isValidInt(input)) {  // Sprawdzamy, czy to poprawna liczba całkowita
            stringstream ss(input);
            if (ss >> wybor && (wybor == 1 || wybor == 2)) {
                kolorowy = (wybor == 1);
                break;
            }
        }
        cout << "Blad: prosze podac 1 lub 2." << endl;
        clearInput();
    }

    // Informacje o sterowaniu
    cout << "  Sterowanie: " << endl;
    cout << "F - Przejdz do nastepnego kroku" << endl;
    cout << "R - Zresetuj rysowanie" << endl;
    cout << "M - Powrot do menu" << endl;
}

void resetProgram()
{
    current_step = 0;  // Resetowanie kroków
    glClear(GL_COLOR_BUFFER_BIT);  // Wyczyszczenie ekranu
    glFlush();
}

void rysuj(double x, double y, double width, int stopien)
{
    if (stopien == 0)
    {
        float deformation_x = 0.f;
        float deformation_y = 0.f;

        glBegin(GL_POLYGON);

        // W trybie kolorowym przypisujemy różne kolory do wierzchołków
        if (kolorowy) {
            for (int i = 0; i < 4; ++i) {
                int indeks = rand() % 15;  // Losowy indeks z rozszerzonej palety kolorów
                glColor3f(paleta_kolorow[indeks][0], paleta_kolorow[indeks][1], paleta_kolorow[indeks][2]);

                // Losowo generowane wierzchołki z deformacją
                if (i == 0) glVertex2f(x + ((float)rand() / RAND_MAX - 0.5f) * width * def_level, y + width + ((float)rand() / RAND_MAX - 0.5f) * width * def_level);
                if (i == 1) glVertex2f(x + width + ((float)rand() / RAND_MAX - 0.5f) * width * def_level, y + width + ((float)rand() / RAND_MAX - 0.5f) * width * def_level);
                if (i == 2) glVertex2f(x + width + ((float)rand() / RAND_MAX - 0.5f) * width * def_level, y + ((float)rand() / RAND_MAX - 0.5f) * width * def_level);
                if (i == 3) glVertex2f(x + ((float)rand() / RAND_MAX - 0.5f) * width * def_level, y + ((float)rand() / RAND_MAX - 0.5f) * width * def_level);
            }
        } else {
            // Tryb czarno-biały, losowy wybór między czarnym a białym dla całej figury
            int indeks = rand() % 2;
            glColor3f(paleta_czarno_biala[indeks][0], paleta_czarno_biala[indeks][1], paleta_czarno_biala[indeks][2]);

            // Rysowanie figury z losowymi deformacjami
            deformation_x = ((float)rand() / RAND_MAX - 0.5f) * width * def_level;
            deformation_y = ((float)rand() / RAND_MAX - 0.5f) * width * def_level;
            glVertex2f(x + deformation_x, y + width + deformation_y);

            deformation_x = ((float)rand() / RAND_MAX - 0.5f) * width * def_level;
            deformation_y = ((float)rand() / RAND_MAX - 0.5f) * width * def_level;
            glVertex2f(x + width + deformation_x, y + width + deformation_y);

            deformation_x = ((float)rand() / RAND_MAX - 0.5f) * width * def_level;
            deformation_y = ((float)rand() / RAND_MAX - 0.5f) * width * def_level;
            glVertex2f(x + width + deformation_x, y + deformation_y);

            deformation_x = ((float)rand() / RAND_MAX - 0.5f) * width * def_level;
            deformation_y = ((float)rand() / RAND_MAX - 0.5f) * width * def_level;
            glVertex2f(x + deformation_x, y + deformation_y);
        }

        glEnd();
    }
    else
    {
        width = width / 3.0f;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++)
                if (i != 1 || j != 1)
                {
                    rysuj(x + i * width, y + j * width, width, stopien - 1);
                }
        }
    }
}

void RenderScene()
{
    if (current_step <= stopien)
    {
        glClear(GL_COLOR_BUFFER_BIT);
        rysuj(x - width / 2., y - width / 2., width, current_step);
        glFlush();
        current_step++; // Zwiększamy krok po każdym rysowaniu
    }
    else
    {
        glBegin(GL_QUADS);
        glColor3f(0.0f, 0.0f, 0.0f);  // Kolor czarny

        glVertex2f(-150.0f, 150.0f);   // Lewy górny róg
        glVertex2f(150.0f, 150.0f);    // Prawy górny róg
        glVertex2f(150.0f, -150.0f);   // Prawy dolny róg
        glVertex2f(-150.0f, -150.0f);  // Lewy dolny róg

        glEnd();
        glFlush();
    }
}

// Zablokowanie możliwości zmiany rozmiaru okna
void ChangeSize(GLsizei horizontal, GLsizei vertical)
{
    glutReshapeWindow(windowWidth, windowHeight);

    glViewport(0, 0, windowWidth, windowHeight);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    glOrtho(-150.0, 150.0, -150.0, 150.0, 1.0, -1.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    width = 300;
}

void HandleKeyPress(unsigned char key, int x, int y)
{
    if (key == 'f' || key == 'F') {
        RenderScene();
    }
    else if (key == 'r' || key == 'R') {
        resetProgram();
    }
    else if (key == 'm' || key == 'M') {
        init();
        resetProgram();
    }
}

int main() {
    int argc = 1;
    char *argv[1] = {(char *) "Something"};

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
    glutInitWindowSize(windowWidth, windowHeight);
    glutCreateWindow("Dywan Sierpinskiego");

    init();
    resetProgram();

    glutDisplayFunc(RenderScene);
    glutReshapeFunc(ChangeSize);
    glutKeyboardFunc(HandleKeyPress);

    glutMainLoop();

    return 0;
}